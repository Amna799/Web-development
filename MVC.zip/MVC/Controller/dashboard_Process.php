<?php
session_start();

// Protect page: redirect to login if user not logged in
if(!isset($_SESSION['user_id'])){
    header("Location: /MVC/View/auth/login.php");
    exit();
}

// Fetch user info from session
$user_id   = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// Example dynamic data (could be fetched from database)
$total_users = 123;  // You can replace this with actual DB query
$profile_info = "Edit your profile";
$settings_info = "Change your preferences";

// Return data to dashboard.php
// We'll use simple PHP variables included in dashboard.php
?>
