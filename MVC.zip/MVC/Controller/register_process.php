<?php
session_start();
require_once '../config/db.php'; // Use require_once for db connection

// Get form data
$firstname  = $_POST['firstname'];
$secondname = $_POST['secondname'];
$email      = $_POST['email'];
$password   = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password

try {
    // Check if email already exists
    $stmt_check = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt_check->execute([$email]);
    $user = $stmt_check->fetch();

    if($user){
        // Email already registered
        header("Location: /MVC/View/auth/register.php?error=Email+already+exists");
        exit();
    }

    // Insert new user
    $stmt = $pdo->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
    $stmt->execute([$email, $password]);

    // Registration successful, redirect to login
    header("Location: /MVC/View/auth/login.php?success=1");
    exit();

} catch (PDOException $e) {
    // Database error
    header("Location: /MVC/View/auth/register.php?error=Registration+failed");
    exit();
}
?>
