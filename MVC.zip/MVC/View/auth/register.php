<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">

  <div class="card shadow-lg p-4" style="width: 100%; max-width: 400px;">
    <h2 class="card-title text-center mb-4">Register</h2>
    <form action="../../Controller/register_process.php" method="POST">

    <div class="mb-3">
        <label for="firstname" class="form-label">First name</label>
        <input type="firstname" class="form-control" id="firstname" name="firstname" aria-describedby="firstHelp" required>
      </div>
      <div class="mb-3">
        <label for="secondname" class="form-label">Second name</label>
        <input type="secondname" class="form-control" id="secondname" name="secondname" aria-describedby="seccondHelp" >
      </div>
      <div class="mb-3">
        <label for="Email" class="form-label">Email address</label>
        <input type="email" class="form-control" id="Email" name="email" aria-describedby="emailHelp" required>
      </div>

      <div class="mb-3">
        <label for="Password" class="form-label">Password</label>
        <input type="password" class="form-control" id="Password" name="password" required>
      </div>

      
      <div class="d-grid gap-2">
        <button type="submit" class="btn btn-primary">Register</button>
      </div>
    </form>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
