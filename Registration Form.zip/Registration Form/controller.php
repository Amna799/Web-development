<?php 
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get form data
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $Cpassword = $_POST['confirmPassword'];
    $gender = $_POST['gender'];

    // Check if passwords match
    if ($password === $Cpassword) {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        try {
            // Prepare SQL insert
            $stmt = $pdo->prepare("INSERT INTO users (fullName, email, password, gender) VALUES (?, ?, ?, ?)");
            $stmt->execute([$fullName, $email, $hashedPassword, $gender]);

            echo "🎉 Registration successful! Welcome, <strong>$fullName</strong>! 🚀💖";
            // Optional: redirect to login page
            // header("Location: login.php");
            // exit;

        } catch (PDOException $e) {
            // Handle duplicate email or other errors
            if ($e->getCode() == 23000) {
                echo "This email is already registered!";
            } else {
                echo "Error: " . $e->getMessage();
            }
        }

    } else {
        echo "Passwords do not match!";
    }
}
?>
