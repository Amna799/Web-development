<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Not authenticated, redirect to login
    header("Location: /MVC/View/auth/login.php?error=3");
    exit;
}
?>
