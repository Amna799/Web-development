<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Get form values
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if ($email && $password) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Save session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];

        header("Location: /MVC/dashboard.php");
        exit;
    } else {
        // Invalid login
        header("Location: /MVC/View/auth/login.php?error=1");
        exit;
    }
} else {
    header("Location: /MVC/View/auth/login.php?error=2");
    exit;
}
?>
